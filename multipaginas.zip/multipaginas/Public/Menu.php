<ul class="nav flex-column">
            <li class="nav-item"> 
              <a class="nav-link d-flex align-items-center gap-2 active" aria-current="page"  href="index.php">Club
                <svg class="bi"><use xlink:href="#house-fill"/></svg>
                Club de ajedrez
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="Cursos.php">Cursos
                <svg class="bi"><use xlink:href="#file-earmark"/></svg>
                Orders
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="Transacciones.php">Compras
                <svg class="bi"><use xlink:href="#cart"/></svg>
                Products
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="Miembros.php">Miembros
                <svg class="bi"><use xlink:href="#people"/></svg>
                Customers
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="Rating.php">Rating
                <svg class="bi"><use xlink:href="#graph-up"/></svg>
                Reports
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="Practica.php">Práctica
                <svg class="bi"><use xlink:href="#puzzle"/></svg>
                Integrations
              </a>
            </li>
          </ul>
