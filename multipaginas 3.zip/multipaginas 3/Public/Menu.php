<ul class="nav flex-column">
            <li class="nav-item"> 
              <a class="nav-link d-flex align-items-center gap-2 active" aria-current="page"  href="index.php">Biblioteca
                <svg class="bi"><use xlink:href="#house-fill"/></svg>
                Club de ajedrez
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="Contenido.php">Contenido
                <svg class="bi"><use xlink:href="#file-earmark"/></svg>
                Orders
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="Comprar.php">Comprar
                <svg class="bi"><use xlink:href="#cart"/></svg>
                Products
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="Blog.php">Blog
                <svg class="bi"><use xlink:href="#people"/></svg>
                Customers
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="Tendencia.php">Tendencia
                <svg class="bi"><use xlink:href="#graph-up"/></svg>
                Reports
              </a>
            </li>
          </ul>
